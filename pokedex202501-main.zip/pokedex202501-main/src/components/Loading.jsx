export const Loading = ()=>{
    return (
        <section className="loadingPanel">
            <div className="loadingProgress">Cargando ...</div>
        </section>
    )
}